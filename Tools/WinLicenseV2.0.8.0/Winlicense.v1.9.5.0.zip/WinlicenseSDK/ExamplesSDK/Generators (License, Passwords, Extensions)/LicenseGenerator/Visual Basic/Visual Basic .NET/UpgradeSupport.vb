Module UpgradeSupport
		Friend DAODBEngine_definst As New DAO.DBEngine
End Module